interface ITodo {
  id: string;
  text: string;
  status: string;
}

export default ITodo;
